# Concrete Stairs Design Academy — Phase 4 MVP

Next.js + TypeScript + Supabase foundation for:
- authentication, learner profiles and corporate tenant membership
- course catalogue, modules and enrollment
- assessments with server-side scoring
- engineering project submissions and senior review
- certificates and minimal public verification
- in-app notifications and tenant-scoped reporting

## Prerequisites
Node.js 20+, npm 10+, a Supabase project. Optional transactional email provider.

## Install
```bash
npm install
cp .env.example .env.local
```
Set the Supabase URL and anon key. Keep the service-role key server-only; never use a `NEXT_PUBLIC_` prefix for it.

## Database
Run `supabase/migrations/202611130001_phase4_core.sql` in the Supabase SQL editor.
Optionally run `supabase/seed.sql`. Enable Supabase Email auth and add
`http://localhost:3000/auth/callback` to allowed redirect URLs.
Create a private Storage bucket named `project-submissions`, then apply
`supabase/storage-policies.sql`.

## Run
```bash
npm run dev
```
Open http://localhost:3000. Register at `/login`; the auth trigger creates a profile.
Assign the first super-admin role through the trusted Supabase SQL editor, not a public API:
```sql
update public.profiles set platform_role='super_admin'
where id='AUTHENTICATED_USER_UUID';
```

## Screens
`/login`, `/dashboard`, `/courses`, `/assessments`, `/projects`, `/reviews`,
`/certificates`, `/notifications`, `/reports`.

## API
- `GET /api/courses`
- `POST /api/enrollments`
- `GET /api/assessments` and `GET /api/assessments/[id]/questions` (answer-key-free question view)
- `POST /api/assessments/attempts`
- `GET, POST /api/projects`
- `GET, POST /api/reviews`
- `GET, POST /api/certificates` (authorized issue after completed enrollment)
- `GET /api/certificates/qr?code=...` (PNG QR)
- `GET /api/certificates`
- `GET /api/certificates/verify?code=...` (public minimal verification)
- `GET /api/notifications`
- `POST /api/notifications/read`
- `POST /api/companies` (super-admin company creation)
- `POST /api/companies/members` (company invitation)
- `GET /api/reports`

## Roles
`super_admin`, `company_admin`, `instructor`, `senior_reviewer`, `learner`.
Public registration cannot assign elevated roles. Use trusted provisioning.

## Email
In-app notification records are implemented. Resend email delivery is wired for review and certificate events. `src/lib/email.ts` is a fail-closed provider
adapter placeholder; connect a provider and a retryable outbox worker before production.

## Safety and release gates
Scores are computed on the server; clients never submit a score. Review decisions are audited.
Certificate verification exposes only minimal details. A certificate proves course completion
only; it is not a professional license or engineering design approval. Keep deterministic
engineering calculations separate from the AI tutor. Validate course examples against the
selected design-code edition and obtain independent engineering review before professional use.

Before production: security review of RLS and role escalation, MFA for privileged roles,
rate limiting, private signed file delivery, malware scanning, email retries, backup/restore test,
accessibility/mobile QA, integration tests, penetration test and independent engineering-content
validation.
