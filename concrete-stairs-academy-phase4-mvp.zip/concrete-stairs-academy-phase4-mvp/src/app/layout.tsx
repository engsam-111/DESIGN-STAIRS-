import "./globals.css";
import Link from "next/link";
export const metadata={title:"Concrete Stairs Design Academy",description:"Professional learning and review for reinforced concrete stair design"};
export default function RootLayout({children}:{children:React.ReactNode}){
 return <html lang="en"><body><header><nav><strong>Concrete Stairs Academy</strong>
 {["dashboard","companies","courses","assessments","projects","reviews","certificates","notifications","reports"].map(x=><Link key={x} href={"/"+x}>{x[0].toUpperCase()+x.slice(1)}</Link>)}
 </nav></header>{children}</body></html>;
}
