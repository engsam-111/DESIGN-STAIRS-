"use client";
import {useEffect,useState} from "react";
export default function Reports(){
 const [data,setData]=useState<any>(null),[error,setError]=useState("");
 useEffect(()=>{fetch("/api/reports").then(r=>r.json()).then(j=>j.error?setError(j.error):setData(j.data));},[]);
 return <main><h1>Reports</h1>{error&&<p>{error}</p>}{data&&<div className="grid">{Object.entries(data).map(([k,v])=><article className="card" key={k}><h2>{String(v)}</h2><p>{k.replaceAll("_"," ")}</p></article>)}</div>}<p className="muted">Metrics are limited by the signed-in user's database access.</p></main>;
}
