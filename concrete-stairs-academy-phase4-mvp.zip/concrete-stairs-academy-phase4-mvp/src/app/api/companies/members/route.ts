import {NextResponse} from "next/server";import {currentUser} from "@/lib/api";import {createAdminClient} from "@/lib/supabase/admin";import {z} from "zod";
export async function POST(req:Request){
 const {user}=await currentUser();if(!user)return NextResponse.json({error:"Authentication required"},{status:401});
 const admin=createAdminClient(),v=z.object({companyId:z.string().uuid(),email:z.string().email(),department:z.string().max(120).optional(),role:z.enum(["learner","instructor","senior_reviewer","company_admin"]).default("learner")}).safeParse(await req.json());
 if(!v.success)return NextResponse.json({error:v.error.flatten()},{status:400});
 const {data:actor}=await admin.from("profiles").select("platform_role").eq("id",user.id).single();
 if(actor?.platform_role!=="super_admin"){const {data:m}=await admin.from("company_memberships").select("id,membership_role").eq("company_id",v.data.companyId).eq("user_id",user.id).eq("is_active",true).maybeSingle();if(!m||m.membership_role!=="company_admin")return NextResponse.json({error:"Company-admin role required"},{status:403});}
 const {data:invite,error:inviteError}=await admin.auth.admin.inviteUserByEmail(v.data.email);
 if(inviteError||!invite.user)return NextResponse.json({error:inviteError?.message??"Invitation failed"},{status:400});
 const {error}=await admin.from("company_memberships").upsert({company_id:v.data.companyId,user_id:invite.user.id,department:v.data.department??null,membership_role:v.data.role,is_active:true},{onConflict:"company_id,user_id"});
 if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({data:{invited:true,email:v.data.email}},{status:201});
}
