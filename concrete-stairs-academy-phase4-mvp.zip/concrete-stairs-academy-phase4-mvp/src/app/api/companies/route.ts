import {NextResponse} from "next/server";import {currentUser} from "@/lib/api";import {createAdminClient} from "@/lib/supabase/admin";import {z} from "zod";
export async function POST(req:Request){
 const {user}=await currentUser();if(!user)return NextResponse.json({error:"Authentication required"},{status:401});
 const admin=createAdminClient(),{data:p}=await admin.from("profiles").select("platform_role").eq("id",user.id).single();
 if(p?.platform_role!=="super_admin")return NextResponse.json({error:"Super-admin role required"},{status:403});
 const v=z.object({name:z.string().trim().min(2).max(120),slug:z.string().trim().toLowerCase().regex(/^[a-z0-9-]{2,80}$/)}).safeParse(await req.json());
 if(!v.success)return NextResponse.json({error:v.error.flatten()},{status:400});
 const {data,error}=await admin.from("companies").insert(v.data).select().single();if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({data},{status:201});
}
