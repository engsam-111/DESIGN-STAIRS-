import {NextResponse} from "next/server";import {currentUser} from "@/lib/api";import {createAdminClient} from "@/lib/supabase/admin";import {z} from "zod";import {sendEmail} from "@/lib/email";
export async function GET(){const {supabase,user}=await currentUser();if(!user)return NextResponse.json({error:"Authentication required"},{status:401});const {data,error}=await supabase.from("certificates").select("id,verification_code,issued_at,revoked_at,courses(title)").eq("user_id",user.id);if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({data});}
export async function POST(req:Request){
 const {user}=await currentUser();if(!user)return NextResponse.json({error:"Authentication required"},{status:401});
 const v=z.object({userId:z.string().uuid(),courseId:z.string().uuid()}).safeParse(await req.json());if(!v.success)return NextResponse.json({error:v.error.flatten()},{status:400});
 const admin=createAdminClient(),{data:actor}=await admin.from("profiles").select("platform_role").eq("id",user.id).single();
 const {data:course}=await admin.from("courses").select("id,company_id,title").eq("id",v.data.courseId).single();if(!course)return NextResponse.json({error:"Course not found"},{status:404});
 let authorized=actor?.platform_role==="super_admin"||(!course.company_id&&actor?.platform_role==="instructor");
 if(!authorized&&course.company_id){const {data:m}=await admin.from("company_memberships").select("membership_role").eq("company_id",course.company_id).eq("user_id",user.id).eq("is_active",true).maybeSingle();authorized=!!m&&["company_admin","instructor"].includes(m.membership_role);}
 if(!authorized)return NextResponse.json({error:"Certificate issuer role required for this course"},{status:403});
 const {data:enrollment}=await admin.from("enrollments").select("id,status").eq("course_id",course.id).eq("user_id",v.data.userId).eq("status","completed").maybeSingle();
 if(!enrollment)return NextResponse.json({error:"Learner must have a completed enrollment"},{status:409});
 const {data:cert,error}=await admin.from("certificates").upsert({user_id:v.data.userId,course_id:course.id,company_id:course.company_id},{onConflict:"user_id,course_id"}).select("id,verification_code,issued_at").single();
 if(error)return NextResponse.json({error:error.message},{status:400});
 const {data:recipient}=await admin.auth.admin.getUserById(v.data.userId);
 const {data:prefs}=await admin.from("notification_preferences").select("email_enabled").eq("user_id",v.data.userId).maybeSingle();
 if(recipient.user?.email&&prefs?.email_enabled)await sendEmail(recipient.user.email,"Your course certificate is available",`<p>Your completion certificate for <strong>${course.title}</strong> is available.</p>`);
 return NextResponse.json({data:cert},{status:201});
}
