import {NextResponse} from "next/server";import {currentUser} from "@/lib/api";import {createAdminClient} from "@/lib/supabase/admin";
export async function GET(){
 const {user}=await currentUser();if(!user)return NextResponse.json({error:"Authentication required"},{status:401});
 const admin=createAdminClient(),{data:p}=await admin.from("profiles").select("platform_role").eq("id",user.id).single();
 if(p?.platform_role==="super_admin"){const [e,pr,ap,c]=await Promise.all([admin.from("enrollments").select("*",{count:"exact",head:true}),admin.from("project_submissions").select("*",{count:"exact",head:true}),admin.from("project_submissions").select("*",{count:"exact",head:true}).eq("status","approved"),admin.from("certificates").select("*",{count:"exact",head:true})]);return NextResponse.json({data:{enrollments:e.count??0,project_submissions:pr.count??0,approved_projects:ap.count??0,certificates_issued:c.count??0}});}
 const {data:members}=await admin.from("company_memberships").select("company_id,membership_role").eq("user_id",user.id).eq("is_active",true).in("membership_role",["company_admin","instructor"]);
 const ids=(members??[]).map(m=>m.company_id);if(!ids.length)return NextResponse.json({error:"Corporate reporting role required"},{status:403});
 const [e,pr,ap,c]=await Promise.all([admin.from("enrollments").select("*",{count:"exact",head:true}).in("company_id",ids),admin.from("project_submissions").select("*",{count:"exact",head:true}).in("company_id",ids),admin.from("project_submissions").select("*",{count:"exact",head:true}).in("company_id",ids).eq("status","approved"),admin.from("certificates").select("*",{count:"exact",head:true}).in("company_id",ids)]);
 return NextResponse.json({data:{enrollments:e.count??0,project_submissions:pr.count??0,approved_projects:ap.count??0,certificates_issued:c.count??0}});
}
