import {NextResponse} from "next/server";import {currentUser} from "@/lib/api";import {createAdminClient} from "@/lib/supabase/admin";import {reviewSchema} from "@/lib/validators";import {sendEmail} from "@/lib/email";
const roles=["senior_reviewer","company_admin"];
export async function GET(){
 const {user}=await currentUser();if(!user)return NextResponse.json({error:"Authentication required"},{status:401});
 const admin=createAdminClient(),{data:p}=await admin.from("profiles").select("platform_role").eq("id",user.id).single();
 if(p?.platform_role==="super_admin"||p?.platform_role==="senior_reviewer"){const {data,error}=await admin.from("project_submissions").select("*").in("status",["submitted","under_review","revision_requested"]);if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({data});}
 const {data:members}=await admin.from("company_memberships").select("company_id,membership_role").eq("user_id",user.id).eq("is_active",true).in("membership_role",roles);
 const ids=(members??[]).map(m=>m.company_id);if(!ids.length)return NextResponse.json({error:"Reviewer role required"},{status:403});
 const {data,error}=await admin.from("project_submissions").select("*").in("company_id",ids).in("status",["submitted","under_review","revision_requested"]);
 if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({data});
}
export async function POST(req:Request){
 const {user}=await currentUser();if(!user)return NextResponse.json({error:"Authentication required"},{status:401});
 const admin=createAdminClient(),v=reviewSchema.safeParse(await req.json());if(!v.success)return NextResponse.json({error:v.error.flatten()},{status:400});
 const {data:p}=await admin.from("profiles").select("platform_role").eq("id",user.id).single();
 const {data:s}=await admin.from("project_submissions").select("id,user_id,company_id").eq("id",v.data.submissionId).single();
 if(!s)return NextResponse.json({error:"Submission not found"},{status:404});
 let authorized=p?.platform_role==="super_admin"||p?.platform_role==="senior_reviewer";
 if(!authorized&&s.company_id){const {data:m}=await admin.from("company_memberships").select("id,membership_role").eq("company_id",s.company_id).eq("user_id",user.id).eq("is_active",true).maybeSingle();authorized=!!m&&roles.includes(m.membership_role);}
 if(!authorized)return NextResponse.json({error:"Reviewer is not assigned to this project company"},{status:403});
 const {data:d,error}=await admin.from("review_decisions").insert({submission_id:s.id,reviewer_id:user.id,decision:v.data.decision,score_percent:v.data.scorePercent??null,comments:v.data.comments}).select().single();
 if(error)return NextResponse.json({error:error.message},{status:400});
 const status=v.data.decision==="approved"?"approved":v.data.decision==="rejected"?"rejected":"revision_requested";
 await admin.from("project_submissions").update({status,updated_at:new Date().toISOString()}).eq("id",s.id);
 await admin.from("notifications").insert({user_id:s.user_id,kind:"review",title:"Project review updated",body:`Your project status is ${status}.`,href:"/projects"});
 await admin.from("audit_events").insert({actor_id:user.id,company_id:s.company_id,action:"project_review_decision",entity_type:"project_submission",entity_id:s.id,metadata:{decision:v.data.decision,score_percent:v.data.scorePercent??null}});
 const [{data:recipient},{data:prefs}]=await Promise.all([admin.auth.admin.getUserById(s.user_id),admin.from("notification_preferences").select("email_enabled").eq("user_id",s.user_id).maybeSingle()]);
 if(recipient.user?.email&&prefs?.email_enabled)await sendEmail(recipient.user.email,"Your engineering project review was updated",`<p>Your project review status is <strong>${status}</strong>.</p>`);
 return NextResponse.json({data:d},{status:201});
}
