import {NextResponse} from "next/server";import {currentUser} from "@/lib/api";import {createAdminClient} from "@/lib/supabase/admin";import {attemptSchema} from "@/lib/validators";
export async function POST(req:Request){
 const {supabase,user}=await currentUser();if(!user)return NextResponse.json({error:"Authentication required"},{status:401});
 const p=attemptSchema.safeParse(await req.json());if(!p.success)return NextResponse.json({error:p.error.flatten()},{status:400});
 const admin=createAdminClient();
 const {data:a}=await admin.from("assessments").select("id,course_id,pass_percent,max_attempts,is_published").eq("id",p.data.assessmentId).single();
 if(!a?.is_published)return NextResponse.json({error:"Assessment unavailable"},{status:404});
 const {data:enrollment}=await admin.from("enrollments").select("id").eq("course_id",a.course_id).eq("user_id",user.id).eq("status","active").maybeSingle();
 if(!enrollment)return NextResponse.json({error:"Active course enrollment required"},{status:403});
 const {count}=await admin.from("assessment_attempts").select("*",{count:"exact",head:true}).eq("assessment_id",a.id).eq("user_id",user.id);
 if((count??0)>=a.max_attempts)return NextResponse.json({error:"Maximum attempts reached"},{status:409});
 const {data:qs,error:qe}=await admin.from("assessment_questions").select("id,correct_option,points").eq("assessment_id",a.id);
 if(qe||!qs?.length)return NextResponse.json({error:"No questions available"},{status:400});
 const allowed=new Set(qs.map(q=>q.id));if(Object.keys(p.data.answers).some(id=>!allowed.has(id)))return NextResponse.json({error:"Answer set contains unknown question IDs"},{status:400});
 let earned=0,total=0;for(const q of qs){total+=Number(q.points);if(p.data.answers[q.id]===q.correct_option)earned+=Number(q.points);}
 const score=total?Math.round(earned/total*10000)/100:0,passed=score>=Number(a.pass_percent);
 const {data,error}=await admin.from("assessment_attempts").insert({assessment_id:a.id,user_id:user.id,score_percent:score,passed,answers:p.data.answers}).select("id,score_percent,passed,submitted_at").single();
 if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({data},{status:201});
}
