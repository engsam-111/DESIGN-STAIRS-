import {NextResponse} from "next/server";import {currentUser} from "@/lib/api";
export async function GET(_req:Request,{params}:{params:{id:string}}){
 const {supabase,user}=await currentUser();if(!user)return NextResponse.json({error:"Authentication required"},{status:401});
 const {data:assessment}=await supabase.from("assessments").select("id,course_id").eq("id",params.id).eq("is_published",true).single();
 if(!assessment)return NextResponse.json({error:"Assessment unavailable"},{status:404});
 const {data:enrollment}=await supabase.from("enrollments").select("id").eq("course_id",assessment.course_id).eq("user_id",user.id).eq("status","active").maybeSingle();
 if(!enrollment)return NextResponse.json({error:"Course enrollment required"},{status:403});
 const {data,error}=await supabase.from("assessment_question_public").select("id,assessment_id,prompt,options,points,sort_order").eq("assessment_id",params.id).order("sort_order");
 if(error)return NextResponse.json({error:error.message},{status:400});return NextResponse.json({data});
}
