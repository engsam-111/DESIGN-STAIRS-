import {createClient} from "@/lib/supabase/server";
export default async function Courses(){
 const s=createClient(),{data:{user}}=await s.auth.getUser();
 const {data:rows}=await s.from("courses").select("id,title,description,level,duration_hours").eq("is_published",true);
 const {data:enrolled}=user?await s.from("enrollments").select("course_id").eq("user_id",user.id):{data:[] as any[]};
 const ids=new Set((enrolled??[]).map((x:any)=>x.course_id));
 return <main><h1>Course catalogue</h1><div className="grid">{(rows??[]).map(c=><article className="card" key={c.id}><h2>{c.title}</h2><p>{c.description}</p><p className="muted">{c.level} · {c.duration_hours} hours</p>
 {ids.has(c.id)?<span className="status">Enrolled</span>:user?<form action="/api/enrollments" method="post"><input type="hidden" name="courseId" value={c.id}/><button>Enroll</button></form>:<a href="/login">Sign in to enroll</a>}</article>)}</div></main>;
}
