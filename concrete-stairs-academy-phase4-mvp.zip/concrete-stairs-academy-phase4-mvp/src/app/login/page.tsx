"use client";
import {FormEvent,useState} from "react";
import {createClient} from "@/lib/supabase/browser";
export default function Login(){
 const [mode,setMode]=useState<"signin"|"signup">("signin"),[email,setEmail]=useState(""),[password,setPassword]=useState(""),[name,setName]=useState(""),[msg,setMsg]=useState("");
 async function submit(e:FormEvent){e.preventDefault();const s=createClient();const r=mode==="signin"?await s.auth.signInWithPassword({email,password}):await s.auth.signUp({email,password,options:{data:{full_name:name},emailRedirectTo:location.origin+"/auth/callback"}});setMsg(r.error?.message??(mode==="signup"?"Check your email to confirm your account.":"Signed in. Open Dashboard."));}
 return <main><section className="card" style={{maxWidth:480,margin:"30px auto"}}><h1>{mode==="signin"?"Sign in":"Create learner account"}</h1><form onSubmit={submit}>
 {mode==="signup"&&<><label>Full name</label><input value={name} onChange={e=>setName(e.target.value)} required/></>}
 <label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/>
 <label>Password</label><input type="password" minLength={8} value={password} onChange={e=>setPassword(e.target.value)} required/>
 <button>{mode==="signin"?"Sign in":"Create account"}</button></form><p>{msg}</p><button onClick={()=>setMode(mode==="signin"?"signup":"signin")}>{mode==="signin"?"Register":"Back to sign in"}</button></section></main>;
}
