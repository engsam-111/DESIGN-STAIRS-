import {createClient} from "@/lib/supabase/server";
export default async function Notifications(){
 const s=createClient(),{data:{user}}=await s.auth.getUser();
 if(!user)return <main><h1>Notifications</h1><p>Sign in to view alerts.</p></main>;
 const {data}=await s.from("notifications").select("*").eq("user_id",user.id).order("created_at",{ascending:false}).limit(100);
 return <main><h1>Notifications</h1>{(data??[]).map(n=><article className="card" key={n.id} style={{marginBottom:10}}><h3>{n.title}</h3><p>{n.body}</p><small>{new Date(n.created_at).toLocaleString()} · {n.read_at?"Read":"Unread"}</small></article>)}</main>;
}
