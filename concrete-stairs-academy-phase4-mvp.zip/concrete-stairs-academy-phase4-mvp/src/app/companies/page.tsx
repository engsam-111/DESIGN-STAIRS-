import {createClient} from "@/lib/supabase/server";
export default async function Companies(){
 const s=createClient(),{data:{user}}=await s.auth.getUser();if(!user)return <main><h1>Corporate accounts</h1><p>Sign in to continue.</p></main>;
 const {data:members}=await s.from("company_memberships").select("company_id,department,membership_role,is_active,companies(name,slug)").eq("user_id",user.id);
 return <main><h1>Corporate account memberships</h1><p>Company administrators provision accounts and invite colleagues through the secured API.</p><div className="grid">{(members??[]).map((m:any)=><article className="card" key={m.company_id}><h2>{m.companies?.name??m.company_id}</h2><p>{m.department??"No department assigned"}</p><span className="status">{m.membership_role}</span><p>{m.is_active?"Active":"Inactive"}</p></article>)}</div></main>;
}
