"use client";
import {FormEvent,useEffect,useState} from "react";
export default function Projects(){
 const [items,setItems]=useState<any[]>([]),[title,setTitle]=useState(""),[brief,setBrief]=useState(""),[msg,setMsg]=useState("");
 async function load(){const r=await fetch("/api/projects"),j=await r.json();setItems(j.data??[]);}
 useEffect(()=>{load();},[]);
 async function submit(e:FormEvent){e.preventDefault();const r=await fetch("/api/projects",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({title,brief})}),j=await r.json();setMsg(j.error??"Draft saved");if(r.ok){setTitle("");setBrief("");load();}}
 return <main><h1>Engineering projects</h1><div className="grid"><section className="card"><h2>New project draft</h2><form onSubmit={submit}><label>Title</label><input value={title} onChange={e=>setTitle(e.target.value)} minLength={4} required/><label>Design brief</label><textarea rows={5} value={brief} onChange={e=>setBrief(e.target.value)}/><button>Save draft</button></form><p>{msg}</p></section><section className="card"><h2>My submissions</h2>{items.map(x=><p key={x.id}>{x.title} — <span className="status">{x.status}</span></p>)}</section></div></main>;
}
