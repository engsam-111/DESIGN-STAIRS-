import {NextResponse} from "next/server";
import {createClient} from "@/lib/supabase/server";
export async function GET(req:Request){const url=new URL(req.url),code=url.searchParams.get("code");if(code){const s=createClient();await s.auth.exchangeCodeForSession(code);}return NextResponse.redirect(new URL("/dashboard",url.origin));}
