import {createClient} from "@/lib/supabase/server";
export default async function Assessments(){
 const s=createClient(),{data:{user}}=await s.auth.getUser();
 const {data}=await s.from("assessments").select("id,title,instructions,pass_percent").eq("is_published",true);
 const {data:attempts}=user?await s.from("assessment_attempts").select("id,assessment_id,score_percent,passed,submitted_at").eq("user_id",user.id).order("submitted_at",{ascending:false}):{data:[] as any[]};
 return <main><h1>Assessments</h1><div className="grid">{(data??[]).map(a=><article className="card" key={a.id}><h2>{a.title}</h2><p>{a.instructions}</p><p>Pass mark: {a.pass_percent}%</p><small>Attempt interface can be connected to the server grading endpoint.</small></article>)}</div><h2>Attempt history</h2><table><thead><tr><th>Submitted</th><th>Assessment ID</th><th>Score</th><th>Result</th></tr></thead><tbody>{(attempts??[]).map(a=><tr key={a.id}><td>{new Date(a.submitted_at).toLocaleString()}</td><td>{a.assessment_id}</td><td>{a.score_percent}%</td><td>{a.passed?"Passed":"Not passed"}</td></tr>)}</tbody></table></main>;
}
