import Link from "next/link";
import {createClient} from "@/lib/supabase/server";
export default async function Dashboard(){
 const s=createClient(),{data:{user}}=await s.auth.getUser();
 if(!user)return <main><h1>Welcome to the Academy</h1><p>Sign in to access your learning workspace.</p><Link href="/login">Sign in / Register</Link></main>;
 const [e,p,c]=await Promise.all([s.from("enrollments").select("*",{count:"exact",head:true}).eq("user_id",user.id),s.from("project_submissions").select("*",{count:"exact",head:true}).eq("user_id",user.id),s.from("certificates").select("*",{count:"exact",head:true}).eq("user_id",user.id)]);
 return <main><h1>Learning dashboard</h1><p className="muted">{user.email}</p><div className="grid">
 {[["Course enrollments",e.count],["Project submissions",p.count],["Certificates",c.count]].map(([k,v])=><div className="card" key={String(k)}><h2>{v??0}</h2><p>{k}</p></div>)}
 </div><section className="card" style={{marginTop:18}}><h2>Learning pathway</h2><p>Learn → Explore → Calculate → Simulate → Design → Verify → Master</p><p>Professional calculations and final design decisions require independent checking.</p></section></main>;
}
