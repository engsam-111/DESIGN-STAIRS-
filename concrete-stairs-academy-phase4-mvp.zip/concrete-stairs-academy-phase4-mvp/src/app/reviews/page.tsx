import {createClient} from "@/lib/supabase/server";
export default async function Reviews(){
 const s=createClient(),{data:{user}}=await s.auth.getUser();
 if(!user)return <main><h1>Senior review</h1><p>Sign in with a reviewer account.</p></main>;
 const {data:p}=await s.from("profiles").select("platform_role").eq("id",user.id).single();
 if(!p||!["senior_reviewer","company_admin","super_admin"].includes(p.platform_role))return <main><h1>Senior review</h1><p>Reviewer permissions required.</p></main>;
 const {data}=await s.from("project_submissions").select("id,title,status,submitted_at").in("status",["submitted","under_review","revision_requested"]);
 return <main><h1>Senior review queue</h1><table><thead><tr><th>Project</th><th>Submitted</th><th>Status</th><th>Record ID</th></tr></thead><tbody>{(data??[]).map(x=><tr key={x.id}><td>{x.title}</td><td>{x.submitted_at??"—"}</td><td>{x.status}</td><td>{x.id}</td></tr>)}</tbody></table><p className="muted">Record decisions through POST /api/reviews.</p></main>;
}
