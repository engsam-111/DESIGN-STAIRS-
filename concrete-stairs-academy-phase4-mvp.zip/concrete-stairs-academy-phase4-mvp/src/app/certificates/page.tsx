import {createClient} from "@/lib/supabase/server";
export default async function Certificates(){
 const s=createClient(),{data:{user}}=await s.auth.getUser();
 if(!user)return <main><h1>Certificates</h1><p>Sign in to view certificates.</p></main>;
 const {data}=await s.from("certificates").select("id,verification_code,issued_at,revoked_at,courses(title)").eq("user_id",user.id);
 const base=process.env.NEXT_PUBLIC_APP_URL??"http://localhost:3000";
 return <main><h1>My certificates</h1><div className="grid">{(data??[]).map(c=><article className="card" key={c.id}><h2>{(c.courses as any)?.title??"Course certificate"}</h2><p>Issued: {new Date(c.issued_at).toLocaleDateString()}</p><p>{c.revoked_at?"Revoked":"Valid record"}</p><p><a href={`${base}/api/certificates/verify?code=${c.verification_code}`}>Verify record</a></p><img alt="Certificate QR code" width="120" height="120" src={`/api/certificates/qr?code=${c.verification_code}`}/></article>)}</div><p className="muted">Course completion only; not professional licensure or design approval.</p></main>;
}
