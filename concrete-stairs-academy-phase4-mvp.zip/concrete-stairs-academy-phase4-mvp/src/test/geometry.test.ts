import {describe,it,expect} from "vitest";
function riserHeight(totalRise:number,risers:number){if(totalRise<=0||risers<=0)throw new Error("Invalid geometry");return totalRise/risers;}
describe("stair geometry helper",()=>{it("calculates equal risers",()=>expect(riserHeight(3000,18)).toBeCloseTo(166.6667,3));it("rejects invalid inputs",()=>expect(()=>riserHeight(0,18)).toThrow());});
