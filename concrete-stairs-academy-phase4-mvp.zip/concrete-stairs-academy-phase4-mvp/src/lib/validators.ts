import { z } from "zod";
export const enrollmentSchema=z.object({courseId:z.string().uuid()});
export const projectSchema=z.object({title:z.string().trim().min(4).max(160),brief:z.string().max(10000).default(""),courseId:z.string().uuid().optional(),filePath:z.string().max(500).optional()});
export const reviewSchema=z.object({submissionId:z.string().uuid(),decision:z.enum(["approved","revision_requested","rejected"]),scorePercent:z.number().min(0).max(100).optional(),comments:z.string().trim().min(5).max(5000)});
export const attemptSchema=z.object({assessmentId:z.string().uuid(),answers:z.record(z.number().int().nonnegative())});
