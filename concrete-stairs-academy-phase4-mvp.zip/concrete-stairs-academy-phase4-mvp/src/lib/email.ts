/** Resend adapter. Delivery is reported only when the provider accepts the request. */
export async function sendEmail(to:string,subject:string,html:string){
 const key=process.env.RESEND_API_KEY,from=process.env.EMAIL_FROM;
 if(!key||!from)return {sent:false,reason:"Email provider is not configured"};
 const response=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Authorization":`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify({from,to,subject,html})});
 if(!response.ok)return {sent:false,reason:`Email provider returned ${response.status}`};
 return {sent:true};
}
