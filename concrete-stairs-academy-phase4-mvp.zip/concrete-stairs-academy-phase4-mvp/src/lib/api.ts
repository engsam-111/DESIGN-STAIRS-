import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
export async function currentUser(){const supabase=createClient();const {data:{user},error}=await supabase.auth.getUser();return {supabase,user:error?null:user};}
export const unauthorized=()=>NextResponse.json({error:"Authentication required"},{status:401});
export const forbidden=()=>NextResponse.json({error:"Insufficient permissions"},{status:403});
