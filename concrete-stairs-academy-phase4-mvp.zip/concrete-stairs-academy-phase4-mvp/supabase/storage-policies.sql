-- Create a PRIVATE bucket named project-submissions in Supabase Storage first.
-- File names must be prefixed with the authenticated user's UUID: <uid>/<submission-id>/file.ext
create policy owner_upload_project_files on storage.objects for insert to authenticated
with check(bucket_id='project-submissions' and (storage.foldername(name))[1]=auth.uid()::text);
create policy owner_read_project_files on storage.objects for select to authenticated
using(bucket_id='project-submissions' and (storage.foldername(name))[1]=auth.uid()::text);
-- Reviewer downloads must be mediated by a server route that checks reviewer role and tenant.
