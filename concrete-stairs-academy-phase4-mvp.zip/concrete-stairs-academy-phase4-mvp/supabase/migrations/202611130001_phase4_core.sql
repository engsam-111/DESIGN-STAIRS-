create extension if not exists pgcrypto;
create type public.platform_role as enum ('super_admin','company_admin','instructor','senior_reviewer','learner');
create type public.enrollment_status as enum ('active','completed','withdrawn');
create type public.project_status as enum ('draft','submitted','under_review','revision_requested','approved','rejected');
create type public.review_decision as enum ('approved','revision_requested','rejected');
create type public.notification_kind as enum ('enrollment','assessment','project','review','certificate','system');

create table public.companies (
 id uuid primary key default gen_random_uuid(), name text not null, slug text not null unique,
 is_active boolean not null default true, created_at timestamptz not null default now()
);
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade, full_name text not null default '',
 job_title text, platform_role public.platform_role not null default 'learner',
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.company_memberships (
 id uuid primary key default gen_random_uuid(), company_id uuid not null references public.companies(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade, department text,
 membership_role public.platform_role not null default 'learner', is_active boolean not null default true,
 created_at timestamptz not null default now(), unique(company_id,user_id)
);
create table public.courses (
 id uuid primary key default gen_random_uuid(), company_id uuid references public.companies(id) on delete cascade,
 title text not null, slug text not null, description text not null default '', level text not null default 'intermediate',
 duration_hours numeric(6,2) not null default 0 check(duration_hours>=0), is_published boolean not null default false,
 created_by uuid references public.profiles(id), created_at timestamptz not null default now(), unique(company_id,slug)
);
create table public.course_modules (
 id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses(id) on delete cascade,
 title text not null, content_md text not null default '', sort_order integer not null default 0,
 estimated_minutes integer not null default 0 check(estimated_minutes>=0)
);
create table public.enrollments (
 id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade, company_id uuid references public.companies(id) on delete cascade,
 status public.enrollment_status not null default 'active', enrolled_at timestamptz not null default now(),
 completed_at timestamptz, unique(course_id,user_id)
);
create table public.assessments (
 id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses(id) on delete cascade,
 title text not null, instructions text not null default '', pass_percent numeric(5,2) not null default 75 check(pass_percent between 0 and 100),
 max_attempts integer not null default 3 check(max_attempts>0), is_published boolean not null default false,
 created_at timestamptz not null default now()
);
create table public.assessment_questions (
 id uuid primary key default gen_random_uuid(), assessment_id uuid not null references public.assessments(id) on delete cascade,
 prompt text not null, options jsonb not null default '[]', correct_option integer not null check(correct_option>=0),
 points numeric(8,2) not null default 1 check(points>0), explanation text not null default '', sort_order integer not null default 0
);
create table public.assessment_attempts (
 id uuid primary key default gen_random_uuid(), assessment_id uuid not null references public.assessments(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade, score_percent numeric(5,2) not null check(score_percent between 0 and 100),
 passed boolean not null, answers jsonb not null default '{}', submitted_at timestamptz not null default now()
);
create table public.project_submissions (
 id uuid primary key default gen_random_uuid(), company_id uuid references public.companies(id) on delete cascade,
 course_id uuid references public.courses(id) on delete set null, user_id uuid not null references public.profiles(id) on delete cascade,
 title text not null, brief text not null default '', file_path text, status public.project_status not null default 'draft',
 submitted_at timestamptz, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.review_decisions (
 id uuid primary key default gen_random_uuid(), submission_id uuid not null references public.project_submissions(id) on delete cascade,
 reviewer_id uuid not null references public.profiles(id), decision public.review_decision not null,
 score_percent numeric(5,2) check(score_percent between 0 and 100), comments text not null,
 criteria jsonb not null default '{}', created_at timestamptz not null default now()
);
create table public.certificates (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 course_id uuid not null references public.courses(id) on delete cascade,
 verification_code text not null unique default encode(gen_random_bytes(16),'hex'),
 issued_at timestamptz not null default now(), revoked_at timestamptz, unique(user_id,course_id)
);
create table public.notifications (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 kind public.notification_kind not null default 'system', title text not null, body text not null, href text,
 read_at timestamptz, created_at timestamptz not null default now()
);
create table public.notification_preferences (
 user_id uuid primary key references public.profiles(id) on delete cascade,
 in_app_enabled boolean not null default true, email_enabled boolean not null default true,
 updated_at timestamptz not null default now()
);
create table public.audit_events (
 id uuid primary key default gen_random_uuid(), actor_id uuid references public.profiles(id),
 company_id uuid references public.companies(id), action text not null, entity_type text not null,
 entity_id uuid, metadata jsonb not null default '{}', created_at timestamptz not null default now()
);

create index memberships_user_company_idx on public.company_memberships(user_id,company_id);
create index enrollments_user_status_idx on public.enrollments(user_id,status);
create index attempts_user_assessment_idx on public.assessment_attempts(user_id,assessment_id,submitted_at desc);
create index projects_tenant_status_idx on public.project_submissions(company_id,status,submitted_at desc);
create index notifications_user_created_idx on public.notifications(user_id,created_at desc);

create function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,full_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''));
 insert into public.notification_preferences(user_id) values(new.id);
 return new;
end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create function public.is_company_member(target_company uuid) returns boolean
language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.company_memberships m where m.company_id=target_company and m.user_id=auth.uid() and m.is_active);
$$;
create function public.has_role(allowed public.platform_role[]) returns boolean
language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles p where p.id=auth.uid() and p.platform_role=any(allowed));
$$;
create function public.has_company_role(target_company uuid, allowed public.platform_role[]) returns boolean
language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.company_memberships m
  where m.company_id=target_company and m.user_id=auth.uid()
    and m.is_active and m.membership_role=any(allowed));
$$;

alter table public.companies enable row level security;
alter table public.profiles enable row level security;
alter table public.company_memberships enable row level security;
alter table public.courses enable row level security;
alter table public.course_modules enable row level security;
alter table public.enrollments enable row level security;
alter table public.assessments enable row level security;
alter table public.assessment_questions enable row level security;
alter table public.assessment_attempts enable row level security;
alter table public.project_submissions enable row level security;
alter table public.review_decisions enable row level security;
alter table public.certificates enable row level security;
alter table public.notifications enable row level security;
alter table public.notification_preferences enable row level security;
alter table public.audit_events enable row level security;

create policy profile_select_self on public.profiles for select using(id=auth.uid() or public.has_role(array['super_admin']::public.platform_role[]));
create policy profile_update_self on public.profiles for update using(id=auth.uid()) with check(id=auth.uid());
-- Prevent self-promotion: only trusted service-role operations may change platform_role.
create function public.prevent_self_role_change() returns trigger language plpgsql as $$
begin
 if new.platform_role is distinct from old.platform_role
    and coalesce(current_setting('request.jwt.claim.role',true),'') <> 'service_role' then
   raise exception 'platform_role can only be changed by trusted administration';
 end if;
 return new;
end; $$;
create trigger protect_profile_role before update on public.profiles
for each row execute procedure public.prevent_self_role_change();
create policy company_select_member on public.companies for select using(public.is_company_member(id) or public.has_role(array['super_admin']::public.platform_role[]));
create policy membership_select_self_or_admin on public.company_memberships for select using(user_id=auth.uid() or public.has_company_role(company_id,array['company_admin']::public.platform_role[]) or public.has_role(array['super_admin']::public.platform_role[]));
create policy course_select_published_or_member on public.courses for select using(is_published or public.is_company_member(company_id) or public.has_role(array['super_admin']::public.platform_role[]));
create policy module_select_course on public.course_modules for select using(exists(select 1 from public.courses c where c.id=course_id and (c.is_published or public.is_company_member(c.company_id))));
create policy enrollment_select_own_or_admin on public.enrollments for select using(user_id=auth.uid() or public.has_company_role(company_id,array['company_admin','instructor']::public.platform_role[]) or public.has_role(array['super_admin']::public.platform_role[]));
create policy enrollment_insert_self on public.enrollments for insert with check(user_id=auth.uid());
create policy assessment_select_published on public.assessments for select using(is_published);
-- Do not expose correct_option to learner clients. Read questions through the safe view below;
-- the grading endpoint uses the service-role client to read the answer key after authentication.
create view public.assessment_question_public as
 select q.id,q.assessment_id,q.prompt,q.options,q.points,q.sort_order
 from public.assessment_questions q
 join public.assessments a on a.id=q.assessment_id
 where a.is_published;
grant select on public.assessment_question_public to authenticated;
create policy attempt_select_own_or_staff on public.assessment_attempts for select using(user_id=auth.uid() or public.has_role(array['instructor','company_admin','super_admin']::public.platform_role[]));
create policy project_select_owner_or_reviewer on public.project_submissions for select using(user_id=auth.uid() or public.has_company_role(company_id,array['senior_reviewer','company_admin']::public.platform_role[]) or public.has_role(array['super_admin','senior_reviewer']::public.platform_role[]));
create policy project_insert_owner on public.project_submissions for insert with check(user_id=auth.uid());
create policy project_update_owner_draft on public.project_submissions for update using(user_id=auth.uid() and status in ('draft','revision_requested')) with check(user_id=auth.uid());
create policy review_select_related on public.review_decisions for select using(reviewer_id=auth.uid() or exists(select 1 from public.project_submissions s where s.id=submission_id and (s.user_id=auth.uid() or public.has_company_role(s.company_id,array['senior_reviewer','company_admin']::public.platform_role[]))) or public.has_role(array['super_admin']::public.platform_role[]));
create policy certificate_select_own on public.certificates for select using(user_id=auth.uid() or public.has_company_role(company_id,array['company_admin']::public.platform_role[]) or public.has_role(array['super_admin']::public.platform_role[]));
create policy notification_own on public.notifications for all using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy notification_preferences_own on public.notification_preferences for all using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy audit_select_admin on public.audit_events for select using(actor_id=auth.uid() or public.has_company_role(company_id,array['company_admin']::public.platform_role[]) or public.has_role(array['super_admin']::public.platform_role[]));

-- Elevated role assignment, question-key access, reviews, certificate issuance and tenant
-- administration require trusted server-side code / reviewed RPCs. Do not grant public writes.
