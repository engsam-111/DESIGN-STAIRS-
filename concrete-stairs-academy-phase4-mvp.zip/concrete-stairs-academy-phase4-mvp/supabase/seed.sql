insert into public.courses(company_id,title,slug,description,level,duration_hours,is_published)
values(null,'Reinforced Concrete Stair Design','reinforced-concrete-stair-design',
'Geometry, support systems, load paths, analysis, reinforcement detailing and technical review.',
'intermediate',26,true) on conflict do nothing;
