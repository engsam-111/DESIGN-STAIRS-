# Engineering learning governance

Course pathway: introduction/anatomy; stair geometry; support systems/load paths; principal stair
design; beam workshop; emergency stair design and comparison; capstone design/review.

Keep the deterministic calculation engine separate from an AI tutor. AI explanations must not
override calculation validation, professional judgment or senior reviewer sign-off. Verify all
worked examples against the selected design-code edition. A completion certificate is not a
professional license, statutory qualification or approval of a real structural design.
