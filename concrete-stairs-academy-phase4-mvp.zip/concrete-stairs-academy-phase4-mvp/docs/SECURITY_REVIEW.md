# Mandatory security review before production

1. Review all RLS policies and tenant boundaries, especially cross-company reviewer access.
2. Prevent users from updating `platform_role` or company membership roles themselves.
3. Move assessment answer-key reads behind a service-only function or restricted view. The starter
   schema exposes question rows under a basic published-assessment policy and needs tightening.
4. Restrict review decisions, certificate issuance and company administration to trusted server-side
   operations or reviewed RPCs.
5. Add tenant authorization to reviewer queue reads and writes.
6. Use private storage, signed URLs, size/type validation, malware scanning and retention rules.
7. Add MFA for privileged users, rate limits, CSRF/abuse controls, audit integrity and alerting.
8. Add email outbox, retries, idempotency, bounce handling and notification preferences.
9. Run dependency scanning, SAST/DAST, penetration testing and backup restore testing.
