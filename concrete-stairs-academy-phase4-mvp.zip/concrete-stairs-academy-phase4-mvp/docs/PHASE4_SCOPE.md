# Phase 4 MVP coverage

- Authentication: email/password UI, profile trigger; company and membership schema.
- Corporate accounts: tenant schema and membership roles. Invitation/provisioning UI remains a release task.
- Courses: course/module schema, published catalogue and learner enrollment endpoint.
- Assessments: question bank schema, server-side scoring and attempt records. Timed/randomized test UI is a release task.
- Projects: learner draft submission UI, project records, senior-review queue and decision API.
- Certificates: certificate records and minimal public verification endpoint. Automated issue/QR rendering remains a release task.
- Notifications: in-app feed and mark-read endpoint. Email provider worker remains a release task.
- Reporting: role-gated aggregate metrics endpoint and dashboard.

Suggested assessment weights: knowledge 20%, calculations 20%, structural exercises 25%, independent project 25%, technical review/presentation 10%. Suggested pass 75%, project minimum 70%, and all critical safety questions passed. These are training policy settings, not statutory requirements.
