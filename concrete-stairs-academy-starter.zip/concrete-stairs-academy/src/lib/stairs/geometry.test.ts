import { describe, expect, it } from "vitest";
import { calculateStairGeometry } from "./geometry";

describe("calculateStairGeometry", () => {
  it("calculates the course example with a 3000 mm floor height", () => {
    const result = calculateStairGeometry({
      floorHeightMm: 3000,
      riserHeightMm: 150,
      goingMm: 300,
      stairWidthMm: 1200,
    });
    expect(result.riserCount).toBe(20);
    expect(result.actualRiserMm).toBe(150);
    expect(result.goingCount).toBe(19);
    expect(result.totalRunMm).toBe(5700);
    expect(result.courseChecks.riseAtOrBelow170).toBe(true);
    expect(result.courseChecks.goingAtOrAbove225).toBe(true);
  });

  it("rejects zero and negative dimensions", () => {
    expect(() => calculateStairGeometry({
      floorHeightMm: 0, riserHeightMm: 150, goingMm: 280, stairWidthMm: 1200,
    })).toThrow(/positive finite number/);
  });

  it("rejects floor height shorter than a proposed riser", () => {
    expect(() => calculateStairGeometry({
      floorHeightMm: 100, riserHeightMm: 150, goingMm: 280, stairWidthMm: 1200,
    })).toThrow(/at least one riser high/);
  });
});
