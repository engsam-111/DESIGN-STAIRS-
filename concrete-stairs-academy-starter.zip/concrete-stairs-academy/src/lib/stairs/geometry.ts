export type StairGeometryInput = {
  floorHeightMm: number;
  riserHeightMm: number;
  goingMm: number;
  stairWidthMm: number;
};

export type StairGeometryResult = {
  riserCount: number;
  actualRiserMm: number;
  goingCount: number;
  totalRunMm: number;
  pitchDegrees: number;
  slopeRatio: number;
  widthMm: number;
  courseChecks: {
    riseAtOrBelow170: boolean;
    goingAtOrAbove225: boolean;
  };
};

export function calculateStairGeometry(input: StairGeometryInput): StairGeometryResult {
  const { floorHeightMm, riserHeightMm, goingMm, stairWidthMm } = input;
  for (const [name, value] of Object.entries(input)) {
    if (!Number.isFinite(value) || value <= 0) {
      throw new Error(`${name} must be a positive finite number`);
    }
  }
  if (floorHeightMm < riserHeightMm) {
    throw new Error("Floor height must be at least one riser high");
  }

  const riserCount = Math.max(1, Math.round(floorHeightMm / riserHeightMm));
  const actualRiserMm = floorHeightMm / riserCount;
  const goingCount = Math.max(0, riserCount - 1);
  const totalRunMm = goingCount * goingMm;
  const pitchDegrees = Math.atan2(actualRiserMm, goingMm) * (180 / Math.PI);

  return {
    riserCount,
    actualRiserMm,
    goingCount,
    totalRunMm,
    pitchDegrees,
    slopeRatio: actualRiserMm / goingMm,
    widthMm: stairWidthMm,
    courseChecks: {
      riseAtOrBelow170: actualRiserMm <= 170,
      goingAtOrAbove225: goingMm >= 225,
    },
  };
}
