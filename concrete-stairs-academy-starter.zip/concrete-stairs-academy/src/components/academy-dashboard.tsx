"use client";

import { useMemo, useState } from "react";
import {
  Activity, ArrowRight, Award, Bell, BookOpen, Building2, Calculator,
  CheckCircle2, ChevronRight, Clock3, GraduationCap, Layers3, Search,
  ShieldCheck, SlidersHorizontal, Users, Waves,
} from "lucide-react";
import { calculateStairGeometry } from "@/lib/stairs/geometry";

const modules = [
  { number: "01", title: "Stair systems & geometry", detail: "Definitions, proportions and dimensional checks", duration: "3 hours", icon: Layers3, progress: 72, tag: "In progress" },
  { number: "02", title: "Support systems & load paths", detail: "Transverse and longitudinal spanning systems", duration: "3 hours", icon: Waves, progress: 0, tag: "Next module" },
  { number: "03", title: "Loads & structural analysis", detail: "Actions, reactions, shear and bending moments", duration: "5 hours", icon: Activity, progress: 0, tag: "Locked" },
  { number: "04", title: "Reinforcement & detailing", detail: "Main bars, distribution steel and anchorage", duration: "5 hours", icon: ShieldCheck, progress: 0, tag: "Locked" },
];

export default function AcademyDashboard() {
  const [active, setActive] = useState("Overview");
  const [floorHeight, setFloorHeight] = useState(3000);
  const [riser, setRiser] = useState(150);
  const [going, setGoing] = useState(300);
  const [width, setWidth] = useState(1200);
  const [showCalculator, setShowCalculator] = useState(false);
  const [search, setSearch] = useState("");

  const geometry = useMemo(() => {
    try {
      return { result: calculateStairGeometry({ floorHeightMm: floorHeight, riserHeightMm: riser, goingMm: going, stairWidthMm: width }), error: "" };
    } catch (error) {
      return { result: null, error: error instanceof Error ? error.message : "Invalid input" };
    }
  }, [floorHeight, riser, going, width]);

  const filteredModules = modules.filter((m) => `${m.title} ${m.detail}`.toLowerCase().includes(search.toLowerCase()));

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Building2 size={22} /></div>
          <div><strong>STAIR<span>LAB</span></strong><small>DESIGN ACADEMY</small></div>
        </div>
        <div className="workspace-label">LEARNING WORKSPACE</div>
        <nav className="nav-list">
          {[
            ["Overview", Activity], ["Learning modules", BookOpen], ["Design calculator", Calculator],
            ["My projects", Layers3], ["Assessments", CheckCircle2], ["Certificates", Award],
          ].map(([label, Icon]) => (
            <button key={label as string} className={`nav-item ${active === label ? "active" : ""}`} onClick={() => { setActive(label as string); if (label === "Design calculator") setShowCalculator(true); }}>
              <Icon size={18} /><span>{label as string}</span>{label === "Learning modules" && <span className="nav-count">6</span>}
            </button>
          ))}
        </nav>
        <div className="sidebar-spacer" />
        <div className="help-card">
          <div className="help-icon"><GraduationCap size={19} /></div>
          <strong>Professional pathway</strong>
          <p>Build your skills from fundamentals to reviewed design projects.</p>
          <button onClick={() => setActive("Learning modules")}>View pathway <ArrowRight size={14} /></button>
        </div>
        <div className="profile">
          <div className="avatar">SE</div><div><strong>Student Engineer</strong><small>Graduate pathway</small></div><SlidersHorizontal size={17} className="profile-settings" />
        </div>
      </aside>

      <section className="main-panel">
        <header className="topbar">
          <div className="breadcrumbs">Academy <ChevronRight size={14} /> <strong>{active}</strong></div>
          <div className="top-actions">
            <div className="search-box"><Search size={16} /><input aria-label="Search learning modules" placeholder="Search modules..." value={search} onChange={(e) => setSearch(e.target.value)} /></div>
            <button className="icon-button" aria-label="Notifications"><Bell size={18} /><i /></button>
            <div className="top-avatar">SE</div>
          </div>
        </header>

        <div className="content">
          <div className="welcome-row">
            <div><div className="eyebrow">THURSDAY, 12 NOVEMBER 2026</div><h1>Good evening, Engineer.</h1><p className="subtitle">Continue your professional development in reinforced-concrete stair design.</p></div>
            <div className="course-chip"><span className="live-dot" /> PROFESSIONAL EDITION</div>
          </div>

          <section className="hero-card">
            <div className="hero-copy">
              <div className="hero-kicker">YOUR LEARNING JOURNEY</div>
              <h2>From stair geometry<br />to professional design.</h2>
              <p>Build confidence through guided lessons, interactive engineering exercises, and structured technical review.</p>
              <button className="primary-button" onClick={() => { setActive("Learning modules"); setShowCalculator(false); }}>Continue learning <ArrowRight size={16} /></button>
            </div>
            <div className="hero-art" aria-label="Abstract architectural stair illustration">
              <div className="art-glow" /><div className="stair-shape"><div /><div /><div /><div /><div /><div /></div>
              <div className="art-caption">STRUCTURE · PRECISION · PRACTICE</div>
            </div>
            <div className="hero-index">01 <span>/ 06</span></div>
          </section>

          <div className="stats-grid">
            <div className="stat-card"><div className="stat-icon violet"><BookOpen size={18} /></div><div><span>COURSE PROGRESS</span><strong>12%</strong><small>of 26 learning hours</small></div><div className="mini-ring"><b>12%</b></div></div>
            <div className="stat-card"><div className="stat-icon blue"><Clock3 size={18} /></div><div><span>LEARNING TIME</span><strong>3.2 hrs</strong><small>Time invested</small></div></div>
            <div className="stat-card"><div className="stat-icon amber"><Award size={18} /></div><div><span>ACHIEVEMENTS</span><strong>02</strong><small>Badges earned</small></div></div>
            <div className="stat-card"><div className="stat-icon green"><CheckCircle2 size={18} /></div><div><span>ASSESSMENT SCORE</span><strong>—</strong><small>No assessment yet</small></div></div>
          </div>

          <div className="section-heading"><div><div className="eyebrow">YOUR CURRICULUM</div><h3>Learning modules</h3></div><button className="text-button" onClick={() => setActive("Learning modules")}>View all modules <ArrowRight size={15} /></button></div>
          <div className="module-list">
            {filteredModules.map((m) => {
              const Icon = m.icon;
              return <article className="module-card" key={m.number}>
                <div className="module-number">{m.number}</div><div className="module-icon"><Icon size={20} /></div>
                <div className="module-info"><div className="module-title-row"><h4>{m.title}</h4><span className={`module-tag ${m.progress ? "tag-progress" : ""}`}>{m.tag}</span></div><p>{m.detail}</p><div className="progress-track"><span style={{ width: `${m.progress}%` }} /></div></div>
                <div className="module-duration"><Clock3 size={14} /> {m.duration}</div><button className="round-arrow" aria-label={`Open ${m.title}`} onClick={() => { setActive("Learning modules"); setShowCalculator(m.number === "01"); }}><ArrowRight size={17} /></button>
              </article>;
            })}
            {filteredModules.length === 0 && <p className="empty-state">No modules match your search.</p>}
          </div>

          <div className="bottom-grid">
            <section className="practice-card">
              <div className="section-heading compact"><div><div className="eyebrow">PRACTICAL WORKSHOP</div><h3>Geometry sandbox</h3></div><span className="beta-pill">INTERACTIVE</span></div>
              <p>Explore the relationship between floor height, risers, goings, and stair pitch.</p>
              <div className="sandbox-preview"><div className="mini-stairs"><span/><span/><span/><span/><span/><span/></div><div className="sandbox-note"><strong>Stair geometry</strong><small>Adjust dimensions and see the results.</small></div></div>
              <button className="outline-button" onClick={() => setShowCalculator(!showCalculator)}>{showCalculator ? "Close calculator" : "Open geometry calculator"} <ArrowRight size={15} /></button>
              {showCalculator && <div className="calculator-panel">
                <div className="calc-inputs">
                  <label>Floor height (mm)<input type="number" min="1" value={floorHeight} onChange={(e) => setFloorHeight(Number(e.target.value))} /></label>
                  <label>Target riser (mm)<input type="number" min="1" value={riser} onChange={(e) => setRiser(Number(e.target.value))} /></label>
                  <label>Going (mm)<input type="number" min="1" value={going} onChange={(e) => setGoing(Number(e.target.value))} /></label>
                  <label>Stair width (mm)<input type="number" min="1" value={width} onChange={(e) => setWidth(Number(e.target.value))} /></label>
                </div>
                {geometry.error ? <p className="calc-error">{geometry.error}</p> : geometry.result && <div className="calc-results">
                  <div><small>RISERS</small><strong>{geometry.result.riserCount}</strong></div>
                  <div><small>ACTUAL RISE</small><strong>{geometry.result.actualRiserMm.toFixed(1)} mm</strong></div>
                  <div><small>HORIZONTAL RUN</small><strong>{(geometry.result.totalRunMm / 1000).toFixed(2)} m</strong></div>
                  <div><small>STAIR PITCH</small><strong>{geometry.result.pitchDegrees.toFixed(1)}°</strong></div>
                  <p className="checks-line">{geometry.result.courseChecks.riseAtOrBelow170 ? "✓" : "!"} Course rise check ≤ 170 mm &nbsp; {geometry.result.courseChecks.goingAtOrAbove225 ? "✓" : "!"} Course going check ≥ 225 mm</p>
                </div>}
                <p className="safety-note">Learning geometry only — not a structural design or building-code approval.</p>
              </div>}
            </section>
            <section className="milestone-card">
              <div className="eyebrow">NEXT MILESTONE</div><div className="milestone-icon"><Award size={22} /></div><h3>Geometry fundamentals</h3><p>Complete the first module and pass its knowledge check to earn your first course milestone.</p><div className="milestone-footer"><span>1 of 6 modules</span><span>17% pathway</span></div><div className="milestone-track"><span /></div>
            </section>
          </div>
          <footer>STAIRLAB ACADEMY <span>LEARN WITH PRECISION.</span><small>Educational platform · Engineering outputs require independent verification.</small></footer>
        </div>
      </section>
    </main>
  );
}
