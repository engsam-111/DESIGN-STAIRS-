import AcademyDashboard from "@/components/academy-dashboard";

export default function Home() {
  return <AcademyDashboard />;
}
