# Architecture — initial decision

## Decision
Start as a modular monolith using Next.js and TypeScript. Keep the engineering calculation domain independent from UI, persistence, and AI services.

## Initial boundaries
- `src/app`: routes and presentation.
- `src/components`: reusable UI.
- `src/lib/stairs`: deterministic stair-domain functions.
- `src/lib/auth`: future authentication and authorization adapters.
- `src/lib/training`: future courses, cohorts, enrollment, and assessments.
- `src/lib/reviews`: future engineering submissions and review workflow.
- `src/lib/notifications`: future in-app and email delivery.
- `prisma`: future relational persistence schema and migrations.

## Rules
1. UI components must not contain engineering formula implementations.
2. Calculation functions must be pure, deterministic, unit-explicit, and independently testable.
3. AI may explain concepts and assist learning, but must never be the source of structural calculation results.
4. Tenant-scoped queries must enforce company membership and role permissions on the server.
5. Engineering submissions must preserve input values, calculation-engine version, code-basis metadata, reviewer decisions, and timestamps.
6. Notifications must be generated from persisted business events; email delivery must not be the only notification record.
7. Certificates must be verifiable by an opaque unique identifier and must not imply professional licensure.

## Deferred decisions
Authentication provider, database hosting, email provider, governing structural design code and edition, and structural calculation scope require explicit decisions.
