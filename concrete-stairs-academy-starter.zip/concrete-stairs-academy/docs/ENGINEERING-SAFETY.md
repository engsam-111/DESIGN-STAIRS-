# Engineering safety and calculation governance

## First-release scope
The initial calculator demonstrates stair geometry only. It does not calculate loads, support reactions, bending moments, shear, reinforcement, deflection, or code compliance.

## Source textbook boundary
The course reference includes geometry criteria and worked examples for principal and emergency stairs. Some calculations or notations may contain transcription or arithmetic inconsistencies. Independently verify them before using them as expected answers, examples, or test fixtures.

## Required controls before structural-design features ship
- Record governing design standard and exact edition for each project.
- Define units explicitly at every calculation boundary.
- Version every calculation engine and preserve the version used for a submission.
- Add hand-calculated benchmark cases reviewed by an independent structural engineer.
- Test boundary conditions, invalid inputs, numerical tolerances, and regression cases.
- Display assumptions, load combinations, support conditions, and limitations.
- Prevent AI-generated values from entering the deterministic calculation path.
- Require qualified review for professional design submissions.
- Label educational outputs as non-approved until validation and review are complete.

## Course-reference geometry checks
The initial learning interface displays the course-reference checks: rise not greater than 170 mm and going not less than 225 mm. These are source-based learning checks, not a substitute for locally applicable building, accessibility, or fire requirements.
