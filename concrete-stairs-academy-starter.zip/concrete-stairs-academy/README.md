# Concrete Stairs Design Academy

Professional learning and engineering-practice platform for reinforced-concrete stair design.

## Included in this starter
- Next.js + TypeScript foundation.
- Responsive academy dashboard.
- Interactive stair geometry learning calculator.
- Pure, deterministic geometry functions and unit tests.
- Initial architecture and engineering-safety documentation.

## Run locally
Requirements: Node.js 20.9+ and npm 10+.

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open http://localhost:3000.

## Quality checks
```bash
npm run typecheck
npm test
npm run lint
npm run build
```

## Important engineering limitation
The current calculator is an educational geometry aid only. It does not perform structural analysis, reinforcement design, code compliance checks, or approve a design. Structural calculations must be implemented as a separate deterministic calculation engine, independently verified against an explicitly selected design-code edition, and reviewed by a qualified engineer before professional use.

## Phase 4 professional training roadmap
1. Role-based access and corporate tenants.
2. Departments, cohorts, course assignment, and deadlines.
3. Learning modules, knowledge checks, and scored assessments.
4. Engineering project submissions, instructor feedback, and senior review.
5. Certificate issuance with unique IDs and public verification.
6. In-app/email notifications and PDF/Excel reporting.
